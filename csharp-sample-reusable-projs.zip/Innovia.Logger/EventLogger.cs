using System;

namespace Innovia.Logger
{
	/// <summary>
	/// Summary description for EventLogger.
	/// </summary>
	public class EventLogger
	{
		public EventLogger()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
