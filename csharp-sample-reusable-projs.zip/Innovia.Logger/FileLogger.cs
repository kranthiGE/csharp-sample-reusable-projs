using System;
using NLog.Targets;


namespace Innovia.Logger
{
	/// <summary>
	/// Summary description for FileLogger.
	/// </summary>
	public class FileLogger
	{
		private static string strFileName = null;
		private static string strLoggerName = null;
		private static string strDebugMsg = null;
		private static System.Exception strExMsg = null;

		public FileLogger()
		{
			
		}

		public void GetAttributes()
		{

		}

		public static void AssignFileName(string FileName)
		{
			strFileName = FileName;
		}

		public static void AssignLoggerName(string LoggerName)
		{
			strLoggerName = LoggerName;
		}

		public static void AssignExceptionInfo(string DebugMessage,System.Exception ExMsg)
		{
			strDebugMsg = DebugMessage;
			strExMsg = ExMsg;
		}

		public static void AssignExceptionInfo(string DebugMessage)
		{
			strDebugMsg = DebugMessage;			
		}

		public static void StoreInFile(string FileName,string LoggerName,string DebugMessage,System.Exception ExMsg)
		{
			AssignFileName(FileName);
			AssignLoggerName(LoggerName);
			AssignExceptionInfo(DebugMessage,ExMsg);

			FileTarget objFile = new FileTarget();
			objFile.FileName = strFileName;
			objFile.KeepFileOpen = false;
			objFile.Layout = "$ {longdate} $ {logger} $ {message} ";

			NLog.Config.SimpleConfigurator.ConfigureForTargetLogging( objFile,NLog.LogLevel.Debug);

			NLog.Logger objNlog = NLog.LogManager.GetLogger(strLoggerName);
			objNlog.Debug(strDebugMsg);
			if(strExMsg != null)
			{
				objNlog.InfoException("Exception Info",strExMsg);
			}
			else if(ExMsg != null)
			{
				objNlog.InfoException("Exception Info",ExMsg);
			}
			
		}

		public static void StoreInFile()
		{
			FileTarget objFile = new FileTarget();
			objFile.FileName = strFileName;
			objFile.KeepFileOpen = false;
			objFile.Layout = "$ {longdate} $ {logger} $ {message} ";

			NLog.Config.SimpleConfigurator.ConfigureForTargetLogging( objFile,NLog.LogLevel.Debug);

			NLog.Logger objNlog = NLog.LogManager.GetLogger(strLoggerName);
			objNlog.Debug(strDebugMsg);
			if(strExMsg != null)
			{
				objNlog.InfoException("Exception Info",strExMsg);
			}			
			
		}
	}
}
