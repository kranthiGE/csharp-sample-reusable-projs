using System;

namespace Innovia.Logger
{
	/// <summary>
	/// Summary description for DataBaseLogger.
	/// </summary>
	public class DataBaseLogger
	{
		public DataBaseLogger()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
