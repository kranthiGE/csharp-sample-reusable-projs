using System;

namespace Innovia.Logger
{
	/// <summary>
	/// Summary description for MailLogger.
	/// </summary>
	public class MailLogger
	{
		public MailLogger()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
