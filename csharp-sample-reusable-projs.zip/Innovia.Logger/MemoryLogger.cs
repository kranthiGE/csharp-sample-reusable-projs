using System;

namespace Innovia.Logger
{
	/// <summary>
	/// Summary description for MemoryLogger.
	/// </summary>
	public class MemoryLogger
	{
		public MemoryLogger()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
