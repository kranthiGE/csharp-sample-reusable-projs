using System;

using Innovia.Exception;
using Innovia.DataAccessLayer;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for User.
	/// </summary>
	public class User
	{
		public User()
		{
			
		}

		
	}
}
