using System;
using System.Web.Mail;
using System.ComponentModel;
using System.Configuration;
using System.Web;
using System.Diagnostics;

using Innovia.Exception;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for Sendmail.
	/// </summary>
	public class clsSendmail
	{
		
		public clsSendmail()
		{
			
			mail = null;
			subject = null;
			body = null;
		}	
		private static MailMessage mail;
		private static string subject;
		private static string body;
		private static string strUname;
		private static string strPwd;
		private static string strSMTP_add;
		private static string strSMTP_Port;
		/// **************************************************************
		/// <summary>
		/// Sets the Subject of the Mail
		/// </summary>
		/// **************************************************************
		public static void SetMailSubject(string subject)
		{
			subject = subject;
		}
		/// **************************************************************
		/// <summary>
		/// Sets the Body of the Mail.
		/// </summary>		
		/// **************************************************************
		public static void SetMailBody(string body)
		{
			body = body;
		}
		/// **************************************************************
		/// <summary>
		/// Sets the Configuration required to Send the Mail.
		/// </summary>		
		/// **************************************************************
		public static void SetConfiguration(string Uname,string Pwd,string SMTP_Add,string SMTP_Port)
		{
			strUname = Uname;
			strPwd = Pwd;
			strSMTP_add = SMTP_Add;
			strSMTP_Port = SMTP_Port;
		}
		/// **************************************************************
		/// <summary>
		/// Sends the mail to the to address from given From Address.		
		/// </summary>		
		/// <param name="mailFrom">From address</param>
		/// <param name="mailTo">To address</param>
		/// <param name="objError">Error object</param>
		/// **************************************************************
		/// 
		public static void SendMailTo(string mailFrom, string mailTo,ref InnoviaError objError)
		{
			mail = new MailMessage();
			mail.From = mailFrom;
			mail.Fields["http://schemas.microsoft.com/cdo/configuration/smtpserver"]
				= strSMTP_add;
			mail.Fields[
				"http://schemas.microsoft.com/cdo/configuration/smtpserverport"] = strSMTP_Port;

				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"] = 1;
				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/sendusername"] = 
					strUname;
				mail.Fields[
					"http://schemas.microsoft.com/cdo/configuration/sendpassword"] = 
					strPwd;
			
			mail.To = mailTo;
			mail.Subject = subject;
			mail.Body = body;
			mail.Priority = MailPriority.High;
			mail.BodyFormat = MailFormat.Html;
			//SmtpMail.SmtpServer = ConfigurationSettings.AppSettings["smtpadd"].ToString();
			try
			{
				SmtpMail.Send(mail);
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
		}
		/// **************************************************************
		/// <summary>
		/// 
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public static void SendMailTo(string mailFrom, string mailTo, string copyTo)
		{
			mail = new MailMessage();
			mail.From = mailFrom;
			mail.To = mailTo;
			mail.Cc = copyTo;
			mail.Subject = subject;
			mail.Body = body;
			mail.Priority = MailPriority.High;
			mail.BodyFormat = MailFormat.Html;
			SmtpMail.SmtpServer = ConfigurationSettings.AppSettings["smtpadd"].ToString();
			SmtpMail.Send(mail);
		}
		
		
	}
}
