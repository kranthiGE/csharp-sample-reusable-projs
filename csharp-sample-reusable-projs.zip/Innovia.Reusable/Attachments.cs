using System;
using System.IO;
using System.Web.UI;
using System.Web;

using Innovia.Exception;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for Attachments.
	/// </summary>
	public class Attachments : System.Web.UI.Page
	{
		public Attachments()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static void CallDisplay(string Path,ref InnoviaError objError)
		{
			Attachments objAttach = new Attachments();
			objAttach.DisplayDownload(Path,ref objError);
		}

		public void DisplayDownload(string strPath,ref InnoviaError objError)
		{
			string strPhysicalPath = null;
			FileInfo objInfo = null;
			try
			{
				strPhysicalPath = Server.MapPath(strPath);
				if(System.IO.File.Exists(strPhysicalPath))
				{
					objInfo = new FileInfo(strPhysicalPath);
					if(Response != null)
					{				
						Response.AddHeader("Content-Disposition", "attachment; filename="+objInfo.Name);
						Response.AddHeader("Content-Length", objInfo.Length.ToString());
						Response.ContentType = "application/octet-stream";
						Response.WriteFile(objInfo.FullName);
					}
				}
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
			finally
			{
				if(Response != null)
				{
					Response.End();
				}
			}
		}

		public static string GetFileName(System.Web.UI.HtmlControls.HtmlInputFile FileUpload)
		{
			int Filelength = FileUpload.PostedFile.FileName.Length;
			int fileindex = 0;
			fileindex =	FileUpload.PostedFile.FileName.LastIndexOf("/");
			if(fileindex == 0 || fileindex < 0)
			{
				fileindex = FileUpload.PostedFile.FileName.LastIndexOf(@"\");
			}
			string strFileName = FileUpload.PostedFile.FileName.Substring(fileindex + 1,Filelength - (fileindex + 1)).ToLower();
			Filelength = 0;
			return strFileName;
		}

		public static string FileExtentionCheck(System.Web.UI.HtmlControls.HtmlInputFile FileUpload)
		{
			int Filelength = FileUpload.PostedFile.FileName.Length;
			int fileindex = FileUpload.PostedFile.FileName.LastIndexOf(".");
			string strFileExtent = FileUpload.PostedFile.FileName.Substring(fileindex,Filelength - fileindex).ToLower();
			Filelength = 0;
			return strFileExtent;
		}

		public static string SaveFile(System.Web.UI.HtmlControls.HtmlInputFile FileUpload,string FileName,string strPath,ref InnoviaError objError)
		{
			string ReturnPath = null;
			if(FileName == null || FileName.CompareTo("") == 0)
			{
				FileName = FileUpload.PostedFile.FileName.Trim();
			}
			if(objError.boolErrorOccurred == false)
			{
                ReturnPath = HttpContext.Current.Server.MapPath(strPath)+FileName;
				if(ReturnPath != null)
				{
					FileUpload.PostedFile.SaveAs(ReturnPath);					
				}
				else
				{
					objError.boolErrorOccurred = true;
					objError.strMessage = "Please enter the Filepath correctly.";
				}
			}
			return strPath + FileName;
		}
		
		public static bool DeleteFile(string strPath,ref InnoviaError objError)
		{
			bool flag = false;
			int lenstr=0;
			int  lastindex=0;
			string Fname=null;
			string Fullpath= null;
			string Fileadd=null;

			Fileadd = strPath;
			lenstr= Fileadd.Length;
						
			lastindex= Fileadd.LastIndexOf("/");
			lastindex+=1;		
			Fname = Fileadd.Substring(lastindex,lenstr-lastindex);

			Fullpath = HttpContext.Current.Server.MapPath(strPath);
			if(File.Exists(Fullpath))
			{
				File.Delete(Fullpath);
				flag = true;
			}
			else
			{
				objError.boolErrorOccurred = true;
				objError.strMessage = "The file doesnt exists in the specified Path.";
			}
			return flag;
		}
	}
}
