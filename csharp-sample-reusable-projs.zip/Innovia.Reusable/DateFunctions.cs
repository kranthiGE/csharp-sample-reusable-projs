using System;

using Innovia.Exception;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for DateFunctions.
	/// </summary>
	public class DateFunctions
	{
		public DateFunctions()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string getMonthName(int intMonthNo)
		{
			string strTmp = null;
			switch(intMonthNo)
			{
				case 1:
					strTmp = "JAN";
					break;
				case 2:
					strTmp = "FEB";
					break;
				case 3:
					strTmp = "MAR";
					break;
				case 4:
					strTmp = "APR";
					break;
				case 5:
					strTmp = "MAY";
					break;
				case 6:
					strTmp = "JUN";
					break;
				case 7:
					strTmp = "JUL";
					break;
				case 8:
					strTmp = "AUG";
					break;
				case 9:
					strTmp = "SEP";
					break;
				case 10:
					strTmp = "OCT";
					break;
				case 11:
					strTmp = "NOV";
					break;
				case 12:
					strTmp = "DEC";
					break;
				default:
					break;
			}
			
			return strTmp;
		}

		public static string ConvertDateToDDMONYY (string strDate)
		{
			return  getDay_DDMMYY(strDate).ToString()+"-"+ getMonthName(getMonth_DDMMYY(strDate))+"-"+ getYear_DDMMYY(strDate);      
		}

		public static int getDay_DDMMYY(string strDate)
		{
			char[] i={'/'};
			string[] arrHolder=strDate.Split(i);
			return Int32.Parse(arrHolder[0]);
		}

		public static int getMonth_DDMMYY(string strDate)
		{
			char[] i={'/'};
			string[] arrHolder=strDate.Split(i);
			return Int32.Parse(arrHolder[1].ToString()  );
		}

		public static int getYear_DDMMYY(string strDate)
		{
			char[] i={'/'};
			string[] arrHolder=strDate.Split(i);
			return Int32.Parse(arrHolder[2].ToString());
		}

		public static bool ValidDate(string strDate,ref InnoviaError objError)
		{
			bool lValid = false;

			try
			{
				System.Globalization.DateTimeFormatInfo dateFormat = new System.Globalization.DateTimeFormatInfo();
				dateFormat.LongDatePattern = "MM/dd/yyyy";

				DateTime dt = DateTime.Parse(strDate, dateFormat);

				lValid = true;
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
				lValid = false;
			}

			return lValid;
		}

		public static bool ValidTime(string strTime,ref InnoviaError objError)
		{
			bool lValid = false;

			try
			{
				System.Globalization.DateTimeFormatInfo dateFormat = new System.Globalization.DateTimeFormatInfo();
				dateFormat.LongDatePattern = "MM/dd/yyyy";

				DateTime dt = DateTime.Parse(strTime, dateFormat);

				lValid = true;
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;

				lValid = false;
			}

			return lValid;
		}

		public static string FormatTime(string strTime, bool bool24HourFormat,ref InnoviaError objError)
		{
			string strRetVal = strTime;

			try
			{
				if (bool24HourFormat == true)
				{
					DateTime miltime = Convert.ToDateTime(strTime);

					strRetVal = miltime.ToString("HH:mm:ss");
				}
				else
				{
					strRetVal = DateTime.Parse(strTime).ToShortTimeString();
				}
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}

			return strRetVal;
		}
	}
}
