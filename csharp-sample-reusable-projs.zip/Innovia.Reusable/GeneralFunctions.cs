using System;
using System.Text.RegularExpressions;

using Innovia.Exception;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for GeneralFunctions.
	/// </summary>
	public class GeneralFunctions
	{
		public GeneralFunctions()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	

		/// **************************************************************
		/// <summary>
		/// Creates a New Password number and returns the Encrypted Password.
		/// </summary>
		/// <param name="objError">Error object</param>
		/// <returns>true or false</returns>
		/// **************************************************************
		public string GenerateForgotPassword_No(ref InnoviaError objError)
		{
			string strText = null;
			Random objRnd = new Random();
			try
			{				
				objRnd = new Random();
				string strPwd = null;					
				int NewPwd = 0;
				NewPwd = objRnd.Next(10000,100000);
				strPwd = LoginFunctions.Encrypt(NewPwd.ToString(),ref objError);			
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
			return strText;
		}


		public object RemoveQuote(string SQLString)
		{
			SQLString = Regex.Replace(SQLString, "'", "''");
			return SQLString;
		}

		public object RemoveHTMLQuote(string SQLString)
		{
			SQLString = Regex.Replace(SQLString, "'", "''");
			SQLString = Regex.Replace(SQLString, "<[^>]*>", "");
			SQLString = Regex.Replace(SQLString, System.Environment.NewLine, "<br>");
			SQLString = SQLString.Replace("<br>","");
			return SQLString;
		}
	}
}
