using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;

using Innovia.Exception;
using Innovia.DataAccessLayer;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for Search.
	/// </summary>
	public class Search
	{
		
		
		DataSet ds = new DataSet();

		DataTable dtable=null;
		DataRow drow=null;
		ArrayList alistData = null;
		ArrayList alist = null;
		string strQry = null;
		string strconnect = null;
		SqlConnection con = null;
		
		string strtest="";
		string getstr="";
		bool flag=false;
		int k=0;
		
		
		

		public Search()
		{
			
		}

		
		public DataRow getDatarow(ArrayList alist_data)
		{
			
			drow=dtable.NewRow();
			for(int i=0;i <= alist_data.Count -1;i++)
			{
				drow[i] = alist_data[0].ToString();
			}
			dtable.Rows.Add(drow);
			return drow;
		}

//		public static DataSet fillingDataset(ArrayList alist_fill)
//		{
//			
//			dtable=ds.Tables.Add("searchresult");
//			for(int i=0;i<=alist_fill.Count-1;i++)
//			{
//				dtable.Columns.Add(alist_fill[i].ToString(),typeof(string));
//			}
//			dtable.Columns.Add("Name",typeof(string));
//			dtable.Columns.Add("Msg",typeof(string));
//			dtable.Columns.Add("Date",typeof(string));
//			dtable.Columns.Add("psId",typeof(string));
//			dtable.Columns.Add("Subject",typeof(string));			
//
//			return ds;
//		}
//		public static DataSet SearchMessage(string strQry,string source,string strCon,Hashtable htble,int searchIndex,ref InnoviaError objError)
//		{
//			SqlConnection objConnect = DbFunctions.getSqlConnection(strCon,ref objError);
//			DataSet dsSearch = new DataSet();
//			ArrayList aInput = new ArrayList();
//			SqlCommand cmd = null;
//			SqlDataReader dr = null;
//			try
//			{				
//				DataRow drow_s = null;								
//				objConnect.Open();
//				cmd = new SqlCommand(strQry,objConnect);
//				dr = cmd.ExecuteReader();
//				aInput = inputList(source.Trim());
//				dsSearch = fillingDataset(htble);
//				while(dr.Read())
//				{
//					if(search(dr[searchIndex].ToString().Trim(),source))
//					{
//						
//						drow_s = getDatarow(objSfields.Name,objSfields.Msg,objSfields.Date,objSfields.psId,objSfields.Subject);
//					}
//				}
//				con.Close();
//
//			}
//			catch(Exception ex)
//			{
//				objError.boolErrorOccurred = true;
//				objError.strMessage = "Error:"+ex.Message.ToString();
//			}
//			finally
//			{
//				dr.Close();
//			}
//			return dsSearch;
//		}
//
//		public bool search(string data,string desiredtext)
//		{
//			alist = new ArrayList();
//			flag=false;
//			int len=data.Length;
//			strtest="";
//			getstr="";
//			k=0;
//			data = data.Trim();
//			for(int i=0;i<=len;i++)
//			{
//				if(i!=data.Length)
//				{
//					strtest=data.Substring(i,1);
//					if(strtest==" " || strtest=="," || strtest=="." || i==len)
//					{
//						getstr=(data).Substring(k,i-k);
//						k=i;
//						alist.Add(getstr.Trim());
//					}
//				}
//				else
//				{
//					getstr=data.Substring(k,i-k);
//					alist.Add(getstr.Trim());
//				}
//			}
//			alist = removeSpaces(alist);
//			for(int i=0;i<alist.Count;i++)
//			{
//				string str=alist[i].ToString().ToLower();
//				for(int j=0;j<aInput.Count;j++)
//				{
//					if(((aInput[j].ToString().ToLower().Trim()).IndexOf(str,0)!=-1) && (str.Trim()).IndexOf(aInput[j].ToString().ToLower(),0)!=-1)
//					{
//						flag=true;		
//						return flag;			
//					}
//					
//				}
//			}
//			alist.Clear();
//			
//			return flag;
//		}
//
//		#region Remove WhiteSpaces in Arraylist
//		public ArrayList removeSpaces(ArrayList alistRemove)
//		{
//			for(int i=0;i<alistRemove.Count;i++)
//			{
//				
//				if( alistRemove[i].ToString().CompareTo(" ")==0)
//				{
//					alistRemove.Remove(alistRemove[i]);
//				}
//				
//			}
//			return alistRemove;
//		}
//		#endregion
//
//		public ArrayList inputList(string input)
//		{
//			
//			k=0;
//			strtest="";
//			getstr="";
//			
//			for(int i=0;i<=input.Length;i++)
//			{
//				if(i!=input.Length)
//				{
//					strtest=input.Substring(i,1);
//					if(strtest==" " || strtest=="," || strtest=="." || i==input.Length)
//					{
//						getstr=(input).Substring(k,i-k);
//						k=i+1;
//						aInput.Add(getstr.Trim());
//					}
//				}
//				else
//				{
//					getstr=input.Substring(k,i-k);
//					aInput.Add(getstr.Trim());
//				}
//			}
//			for(int i=0;i<aInput.Count;i++)
//			{
//				
//				if( aInput[i].ToString().CompareTo(" ")==0)
//				{
//					aInput.Remove(aInput[i]);
//				}
//				
//			}
//			
//			return aInput;
//		}

	}
}
