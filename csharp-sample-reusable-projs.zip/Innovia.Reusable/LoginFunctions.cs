using System;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Data.SqlClient;

using Innovia.Exception;
using Innovia.DataAccessLayer;

namespace Innovia.Reusable
{
	/// <summary>
	/// Summary description for LoginFunctions.
	/// </summary>
	public class LoginFunctions
	{
		public LoginFunctions()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static string Encrypt(string Source,ref InnoviaError objError)
		{
			string strEncrypt = string.Empty;
			byte[] byteArray = null;
			ASCIIEncoding asciiEncode = null;
			try
			{
				byteArray = new byte[Source.Length];
				asciiEncode = new ASCIIEncoding();
				asciiEncode.GetBytes(Source,0,Source.Length,byteArray,0);
				SHA256Managed objSha = new SHA256Managed();
				byteArray = objSha.ComputeHash(byteArray);
				for(int k=0;k<byteArray.Length;k++)
				{
					strEncrypt = strEncrypt + byteArray[k].ToString();
				}

			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
			return strEncrypt;
		}

		

		public string GenerateRandom(string Pid,string Constr,string strQry,string ColName,int min,int max,ref InnoviaError objError)
		{
			SqlConnection objConnect = DbFunctions.getSqlConnection(Constr,ref objError);
			Random objRnd = new Random();
			CreateID:
				string Id = null;
			int rndNo = 0;
			try
			{
				rndNo = objRnd.Next(min,max);
				Pid = Pid+rndNo.ToString();				
				if(DbFunctions.CheckExistence(Pid,strQry,objConnect,ColName,ref objError))
				{
					Id = Pid;
					rndNo = 0;
					Pid = null;
					strQry = null;
				}
				else
				{
					goto CreateID;
				}
				
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}

			return Id;
		}

		public static bool Authenticator(string Constr,string strQry,string Uname,string Pwd,string RoleId,string strU,string strP,string strR,ref InnoviaError objError)
		{
			DataSet dsLogin = null;
			DataRow[] drows = null;
			bool authenticated = false;
			try
			{
				dsLogin = PopulateUserData(strQry,Constr,ref objError);
				if(objError.boolErrorOccurred == false)
				{
				
					string strPwd = Encrypt(Pwd,ref objError);
					if(dsLogin != null || dsLogin.Tables.Count != 0)
					{
						if(RoleId != null)
						{
							drows = dsLogin.Tables[0].Select(""+strU+" = '"+ Uname +"' and "+strP+" = '"+ strPwd +"' and "+strR+" = '"+RoleId+"'");
						}
						else
						{
							drows = dsLogin.Tables[0].Select(""+strU+" = '"+Uname+"' and "+strP+" = '"+strPwd+"'");
						}
					
						if(drows.Length > 0)
						{
							authenticated = true;							
						}
					}
				}
				
			
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
			finally
			{
				if(objError.boolErrorOccurred == false)
				{
					dsLogin = null;	
					if(drows != null)
					{
						drows = null;
					}
				}
			}
			return authenticated;
		}

		/// **************************************************************
		/// <summary>
		/// Popelates the data of the user
		/// </summary>
		/// <returns>true or false</returns>
		/// **************************************************************
		public static DataSet PopulateUserData(string strQry,string Constr,ref InnoviaError objError)
		{		
			DataSet dsLogin = null;
			dsLogin = new DataSet();	
			try
			{
				SqlConnection objConnect = DbFunctions.getSqlConnection(Constr,ref objError);
				dsLogin = DbFunctions.GetDatasetValues(strQry,objConnect,ref objError);				
			}
			catch(InnoviaException ex)
			{
				//Report error via error object
				objError.boolErrorOccurred = true;
				objError.strMessage = "Error:"+ex.Message.ToString();
				ex.ErrorNumber = ex.ErrorNumber + 1;
			}
			return dsLogin;
		}

		
	}
}
