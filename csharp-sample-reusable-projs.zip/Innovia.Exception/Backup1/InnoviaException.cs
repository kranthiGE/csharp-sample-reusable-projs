using System;

namespace Innovia.Exception
{
	/// <summary>
	/// Summary description for InnoviaException.
	/// </summary>
	public class InnoviaException : ApplicationException
	{
		#region Private variable Creation

		private int _ErrorNumber;
		private string _ErrorCode;
		private string _Message;

		#endregion


		public InnoviaException()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		#region Property : ErrorCode

		public string ErrorCode
		{
			get
			{
				return _ErrorCode;
			}
			set
			{
				_ErrorCode = value;		
			}
		}

		#endregion

		#region Property : ErrorMessage

		public string ErrorMessage
		{
			get
			{
				return _Message;
			}
			set
			{
				_Message = value;
			}
		}

		#endregion

		#region Property : ErrorNumber

		public int ErrorNumber
		{
			get
			{
				return _ErrorNumber;
			}
			set
			{
				_ErrorNumber = value;
			}
		}

		#endregion
	}
}
