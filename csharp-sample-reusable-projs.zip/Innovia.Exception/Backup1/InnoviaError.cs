using System;

namespace Innovia.Exception
{
	/// <summary>
	/// Summary description for InnoviaError.
	/// </summary>
	public class InnoviaError
	{
		#region Private variable Creation

		public string strMessage = null;
		public bool boolErrorOccurred = false;

		#endregion

		public InnoviaError()
		{
			Reset();
		}

		/// **************************************************************
		/// <summary>
		/// Method to Reset object , ie clear string and set flag to false
		/// </summary>		
		///  Kiran - 19/07/2006
		/// **************************************************************
		
		public void Reset()
		{
			boolErrorOccurred = false;
			strMessage=""; 
		}
	}
}
