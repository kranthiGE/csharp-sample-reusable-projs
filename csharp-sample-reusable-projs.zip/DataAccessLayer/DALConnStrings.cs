using System;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALConnStrings.
	/// </summary>
	public class DALConnStrings
	{
		private static DALConnStrings m_Instance;
		private static System.Threading.Mutex m_Mutex = new System.Threading.Mutex();
		private static NameValueCollection m_colConnectStrings;

		static DALConnStrings()
		{
			m_colConnectStrings = (NameValueCollection)ConfigurationSettings.GetConfig("appSettings");
		}

		public static DALConnStrings GetInstance()
		{
			m_Mutex.WaitOne();
			if(m_Instance == null)
			{
				m_Instance = new DALConnStrings();				
			}
			m_Mutex.ReleaseMutex();
			return m_Instance;
		}

		public string GetConnectStringByRole(DALRequest.UserRole Role)
		{
			return m_colConnectStrings.Get((int)Role - 1).ToString();
		}
	}
}
