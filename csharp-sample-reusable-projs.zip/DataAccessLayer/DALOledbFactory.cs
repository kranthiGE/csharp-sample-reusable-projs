using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

using Innovia.Exception;
using Innovia.Logger;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALOledbFactory.
	/// </summary>
	public class DALOledbFactory : DALAbstractFactory
	{
		private string strLogFileName = ConfigurationSettings.AppSettings["FileName"].ToString();
		private OleDbConnection m_conOLEDB = new OleDbConnection();

		public override DataReader ExecuteDataReader(DALRequest Request)
		{
			OleDbCommand cmdOLEDB = new OleDbCommand();
			OleDbParameter prmOLEDB;
			OleDbDataReader drOLEDB;
			DALOledbDatareader oDataReaderOLEDB = new DALOledbDatareader();
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();
				m_conOLEDB.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				m_conOLEDB.Open();
				cmdOLEDB.Connection = m_conOLEDB;
				cmdOLEDB.CommandText = Request.Command;
				cmdOLEDB.CommandType = Request.CommandType;

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmOLEDB = cmdOLEDB.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}

				drOLEDB = cmdOLEDB.ExecuteReader();

				oDataReaderOLEDB.ReturnDataReader = drOLEDB;
			
			}
			catch(Exception ex)
			{
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();
				
				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			return oDataReaderOLEDB;
		}

		~DALOledbFactory()
		{
			if((m_conOLEDB.State != ConnectionState.Closed) || (m_conOLEDB.State != ConnectionState.Broken))
			{
				m_conOLEDB.Close();
			}
		}

		public override Dataset ExecuteDataSet(DALRequest Request)
		{
			OleDbConnection conOLEDB = new OleDbConnection();
			OleDbCommand cmdOLEDB = new OleDbCommand();
			OleDbParameter prmOLEDB;
			OleDbDataAdapter daOLEDB;
			DALOledbDataset oDataSetOLEDB = new DALOledbDataset();
			OleDbTransaction tranOLEDB = null;

			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conOLEDB.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conOLEDB.Open();
				cmdOLEDB.Connection = conOLEDB;
				cmdOLEDB.CommandText = Request.Command;
				cmdOLEDB.CommandType = Request.CommandType;

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmOLEDB = cmdOLEDB.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranOLEDB = conOLEDB.BeginTransaction();
				}

				daOLEDB = new OleDbDataAdapter(cmdOLEDB);
				daOLEDB.Fill(oDataSetOLEDB.ReturnDataset);				
			}
			catch(OleDbException OledbEx)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = OledbEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,OledbEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranOLEDB.Commit();
				}
				if(conOLEDB.State == ConnectionState.Open)
				{
					conOLEDB.Close();
				}
			}
			return oDataSetOLEDB;
		}

		public override int ExecuteNonQuery(DALRequest Request)
		{
			OleDbConnection conOLEDB = new OleDbConnection();
			OleDbCommand cmdOLEDB = new OleDbCommand();
			OleDbParameter prmOLEDB;
			OleDbTransaction tranOLEDB = null;
			DALOledbExecuteQuery oExNonqueryOLEDB = new DALOledbExecuteQuery();
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conOLEDB.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conOLEDB.Open();
				cmdOLEDB.Connection = conOLEDB;
				cmdOLEDB.CommandText = Request.Command;
				cmdOLEDB.CommandType = Request.CommandType;
				
				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmOLEDB = cmdOLEDB.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranOLEDB = conOLEDB.BeginTransaction();
				}
				
				oExNonqueryOLEDB.ExecuteNonQuery = cmdOLEDB.ExecuteNonQuery();
			}
			catch(OleDbException OledbEx)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = OledbEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,OledbEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranOLEDB.Commit();
				}
				if(conOLEDB.State == ConnectionState.Open)
				{
					conOLEDB.Close();
				}
			}

			return oExNonqueryOLEDB.ExecuteNonQuery;
		}
			
		public override object ExecuteScalar(DALRequest Request)
		{
			OleDbConnection conOLEDB = new OleDbConnection();
			OleDbCommand cmdOLEDB = new OleDbCommand();
			OleDbParameter prmOLEDB;
			OleDbTransaction tranOLEDB = null;
			DALOledbExecuteQuery oExNonqueryOLEDB = new DALOledbExecuteQuery();
			
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conOLEDB.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conOLEDB.Open();
				cmdOLEDB.Connection = conOLEDB;
				cmdOLEDB.CommandText = Request.Command;
				cmdOLEDB.CommandType = Request.CommandType;				

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmOLEDB = cmdOLEDB.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranOLEDB = conOLEDB.BeginTransaction();
				}

				oExNonqueryOLEDB.ExecuteScalar = cmdOLEDB.ExecuteScalar();
			}
			catch(OleDbException OledbEx)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = OledbEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,OledbEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranOLEDB.Rollback();
				}
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranOLEDB.Commit();
				}
				if(conOLEDB.State == ConnectionState.Open)
				{
					conOLEDB.Close();
				}
			}
			return oExNonqueryOLEDB.ExecuteScalar;
		}
	}
}
