using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

using Innovia.Exception;
using Innovia.Logger;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALSqlAbstractFactory.
	/// </summary>
	public class DALSQLFactory : DALAbstractFactory
	{
		private string strLogFileName = ConfigurationSettings.AppSettings["FileName"].ToString();
		private SqlConnection m_conSQL = new SqlConnection();
	
        public override DataReader ExecuteDataReader(DALRequest Request)
		{
			SqlCommand cmdSQL = new SqlCommand();
			SqlParameter prmSQL;
			SqlDataReader drSQL;
			DALSqlDatareader oDataReaderSQL = new DALSqlDatareader();
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();
				m_conSQL.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				m_conSQL.Open();
				cmdSQL.Connection = m_conSQL;
				cmdSQL.CommandText = Request.Command;
				cmdSQL.CommandType = Request.CommandType;

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmSQL = cmdSQL.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}

				drSQL = cmdSQL.ExecuteReader();

				oDataReaderSQL.ReturnDataReader = drSQL;
			
			}
			catch(Exception ex)
			{
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			return oDataReaderSQL;
		}

		~DALSQLFactory()
		{
			if((m_conSQL.State != ConnectionState.Closed) || (m_conSQL.State != ConnectionState.Broken))
			{
				m_conSQL.Close();
			}
		}

		public override DataAccessLayer.Dataset ExecuteDataSet(DALRequest Request)
		{
			SqlConnection conSQL = new SqlConnection();
			SqlCommand cmdSQL = new SqlCommand();
			SqlParameter prmSQL;
			SqlDataAdapter daSQl;
			DALSqlDataset oDataSetSQL = new DALSqlDataset();
			SqlTransaction tranSQL = null;

			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conSQL.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conSQL.Open();
				cmdSQL.Connection = conSQL;
				cmdSQL.CommandText = Request.Command;
				cmdSQL.CommandType = Request.CommandType;

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmSQL = cmdSQL.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranSQL = conSQL.BeginTransaction();
				}

				daSQl = new SqlDataAdapter(cmdSQL);
				daSQl.Fill(oDataSetSQL.ReturnDataset);				
			}
			catch(SqlException sqlEx)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = sqlEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,sqlEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranSQL.Commit();
				}
				if(conSQL.State == ConnectionState.Open)
				{
					conSQL.Close();
				}
			}
			return oDataSetSQL;
		}

		public override int ExecuteNonQuery(DALRequest Request)
		{
			SqlConnection conSQL = new SqlConnection();
			SqlCommand cmdSQL = new SqlCommand();
			SqlParameter prmSQL;
			SqlTransaction tranSQL = null;
			DALSqlExecuteQuery oExNonquerySQL = new DALSqlExecuteQuery();
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conSQL.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conSQL.Open();
				cmdSQL.Connection = conSQL;
				cmdSQL.CommandText = Request.Command;
				cmdSQL.CommandType = Request.CommandType;
				
				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmSQL = cmdSQL.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranSQL = conSQL.BeginTransaction();
				}
				
				oExNonquerySQL.ExecuteNonQuery = cmdSQL.ExecuteNonQuery();
			}
			catch(SqlException sqlEx)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = sqlEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,sqlEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}

				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranSQL.Commit();
				}
				if(conSQL.State == ConnectionState.Open)
				{
					conSQL.Close();
				}
			}

			return oExNonquerySQL.ExecuteNonQuery;
		}
			
		public override object ExecuteScalar(DALRequest Request)
		{
			SqlConnection conSQL = new SqlConnection();
			SqlCommand cmdSQL = new SqlCommand();
			SqlParameter prmSQL;
			SqlTransaction tranSQL = null;
			DALSqlExecuteQuery oExNonquerySQL = new DALSqlExecuteQuery();
			
			try
			{
				DALConnStrings oCon = DALConnStrings.GetInstance();				
				conSQL.ConnectionString = oCon.GetConnectStringByRole(Request.Role);
				conSQL.Open();
				cmdSQL.Connection = conSQL;
				cmdSQL.CommandText = Request.Command;
				cmdSQL.CommandType = Request.CommandType;				

				if(Request.Parameters.Count > 0)
				{
					foreach(DALRequest.Parameter oParam in Request.Parameters)
					{
						prmSQL = cmdSQL.Parameters.Add(oParam.ParamName,oParam.ParamValue);
					}
				}
				
				if(Request.Transactional)
				{
					tranSQL = conSQL.BeginTransaction();
				}

				oExNonquerySQL.ExecuteScalar = cmdSQL.ExecuteScalar();
			}
			catch(SqlException sqlEx)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = sqlEx.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,sqlEx);
				FileLogger.StoreInFile();
			}
			catch(Exception ex)
			{
				if(Request.Transactional)
				{
					tranSQL.Rollback();
				}
				Request.Error.boolErrorOccurred = true;
				Request.Error.strMessage = ex.Message.ToString();

				//Logs the error via Logger object
				FileLogger.AssignLoggerName("Error in DataAccess Layer");
				FileLogger.AssignFileName(strLogFileName);
				FileLogger.AssignExceptionInfo(Request.Error.strMessage,ex);
				FileLogger.StoreInFile();
			}
			finally
			{
				if(Request.Transactional)
				{
					tranSQL.Commit();
				}
				if(conSQL.State == ConnectionState.Open)
				{
					conSQL.Close();
				}
			}
			return oExNonquerySQL.ExecuteScalar;
		}

	}
}
