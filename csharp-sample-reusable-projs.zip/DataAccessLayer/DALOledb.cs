using System;
using System.Data;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALOledb.
	/// </summary>
	public class DALOledbDatareader : DataReader
	{
		IDataReader m_oDatareader;

		public override IDataReader ReturnDataReader
		{
			get
			{
				return m_oDatareader;
			}
			set
			{
				m_oDatareader = value;
			}
		}
	}

	public class DALOledbDataset : Dataset
	{
		DataSet m_oDataset;

		public override DataSet ReturnDataset
		{
			get
			{
				return m_oDataset;
			}
			set
			{
				m_oDataset = value;
			}
		}
	}

	public class DALOledbExecuteQuery : ExecuteQuery
	{
		int m_oResult;

		object m_oScalar;

		public override int ExecuteNonQuery
		{
			get
			{
				return m_oResult;
			}
			set
			{
				m_oResult = value;
			}
		}

		public override object ExecuteScalar
		{
			get
			{
				return m_oScalar;
			}
			set
			{
				m_oScalar = value;
			}
		}

	}
}
