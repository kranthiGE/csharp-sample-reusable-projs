using System;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for ExecuteQuery.
	/// </summary>
	public abstract class ExecuteQuery
	{
		public abstract int ExecuteNonQuery
		{
			get;
			set;
		}
		
		public abstract object ExecuteScalar
		{
			get;
			set;
		}
	}
}
