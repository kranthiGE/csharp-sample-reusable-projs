using System;
using System.Data;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for Dataset.
	/// </summary>
	public abstract class Dataset
	{
		public abstract DataSet ReturnDataset
		{
			get;
			set;
		}
	}
}
