using System;
using System.Data;
using System.Collections;

using Innovia.Exception;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALRequest.
	/// </summary>
	public class DALRequest
	{
		public enum UserRole
		{
			External = 1,			
			Internal = 6,
			SuperUser = 3,
			Admin = 4,
			MSAccess = 5,
			SqlServer = 2,
			Oracle = 7
		}

		public class Parameter
		{
			private string m_sParamName;
			private string m_sParamValue;

			public string ParamName
			{
				get
				{
					return m_sParamName;
				}
				set
				{
					m_sParamName = value;
				}
			}

			public string ParamValue
			{
				get
				{
					return m_sParamValue;
				}
				set
				{
					m_sParamValue = value;
				}
			}
		}
			private UserRole m_lUserRole;
			private CommandType m_lCommandType;
			private string m_sCommand;
			private bool m_bTransactional;
			private ArrayList m_colParameters = new ArrayList();
			private InnoviaException m_oException;
			private InnoviaError m_oError;

			public UserRole Role
			{
				get
				{	
					return m_lUserRole;
				}
				set
				{
					m_lUserRole = value;
				}
			}

			public CommandType CommandType
			{
				get
				{
					return m_lCommandType;
				}
				set
				{
					m_lCommandType = value;
				}
			}

			public string Command
			{
				get
				{
					return m_sCommand;
				}
				set
				{		
					m_sCommand = value;
				}	
			}
			
			public bool Transactional
			{
				get
				{
					return m_bTransactional;
				}
				set
				{
					m_bTransactional = value;
				}
			}

			public ArrayList Parameters
			{
				get
				{
					return m_colParameters;
				}
				set
				{
					m_colParameters = value;
				}
			}

			public InnoviaException Exception
			{
				get
				{
					return m_oException;
				}
				set
				{
					m_oException = value;
				}
			}

			public InnoviaError Error
			{
				get
				{
					return m_oError;
				}
				set
				{
					m_oError = value;
				}
			}
		
	}
}
