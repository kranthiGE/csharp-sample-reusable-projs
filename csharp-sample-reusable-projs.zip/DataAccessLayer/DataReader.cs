using System;
using System.Data;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DataReader.
	/// </summary>
	public abstract class DataReader
	{
		public abstract IDataReader ReturnDataReader
        {
			get;
			set;
		}
	}
}
