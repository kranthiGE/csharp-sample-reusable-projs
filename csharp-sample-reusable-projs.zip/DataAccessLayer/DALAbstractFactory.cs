using System;

namespace DataAccessLayer
{
	/// <summary>
	/// Summary description for DALAbstractFactory.
	/// </summary>
	public abstract class DALAbstractFactory
	{
		public abstract DataReader ExecuteDataReader(DALRequest Request);
		public abstract Dataset ExecuteDataSet(DALRequest Request);		
		public abstract int ExecuteNonQuery(DALRequest Request);
		public abstract object ExecuteScalar(DALRequest Request);
	}
}
